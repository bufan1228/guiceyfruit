/**
 * Copyright (C) 2006 Google Inc.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.google.inject;

import com.google.inject.internal.Errors;
import com.google.inject.internal.ErrorsException;
import com.google.inject.spi.Closeable;
import com.google.inject.spi.Dependency;
import com.google.inject.spi.Closer;
import com.google.inject.spi.CloseErrors;

/**
 * @author crazybob@google.com (Bob Lee)
 */
class ProviderToInternalFactoryAdapter<T> implements Provider<T>, Closeable {

  private final InjectorImpl injector;
  private final InternalFactory<? extends T> internalFactory;

  public ProviderToInternalFactoryAdapter(InjectorImpl injector,
      InternalFactory<? extends T> internalFactory) {
    this.injector = injector;
    this.internalFactory = internalFactory;
  }

  public T get() {
    final Errors errors = new Errors();
    try {
      T t = injector.callInContext(new ContextualCallable<T>() {
        public T call(InternalContext context) throws ErrorsException {
          Dependency dependency = context.getDependency();
          return internalFactory.get(errors, context, dependency);
        }
      });
      errors.throwIfNecessary();
      return t;
    } catch (ErrorsException e) {
      throw new ProvisionException(errors.merge(e.getErrors()));
    }
  }

  public void close(Closer closer, CloseErrors errors) {
    if (internalFactory instanceof Closeable) {
      Closeable closeable = (Closeable) internalFactory;
      closeable.close(closer, errors);
    }
  }

  @Override public String toString() {
    return internalFactory.toString();
  }
}
