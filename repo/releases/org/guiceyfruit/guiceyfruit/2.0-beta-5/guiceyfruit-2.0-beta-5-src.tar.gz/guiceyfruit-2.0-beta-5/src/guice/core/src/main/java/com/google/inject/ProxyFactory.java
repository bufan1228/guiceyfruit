/**
 * Copyright (C) 2006 Google Inc.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.google.inject;

import com.google.common.collect.Lists;
import com.google.common.collect.Maps;
import com.google.inject.internal.BytecodeGen.Visibility;
import static com.google.inject.internal.BytecodeGen.newEnhancer;
import static com.google.inject.internal.BytecodeGen.newFastClass;
import com.google.inject.internal.Errors;
import com.google.inject.internal.ErrorsException;
import com.google.inject.internal.FailableCache;
import com.google.inject.spi.InjectionPoint;
import java.lang.reflect.Constructor;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.lang.reflect.AccessibleObject;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import net.sf.cglib.proxy.Callback;
import net.sf.cglib.proxy.CallbackFilter;
import net.sf.cglib.proxy.Enhancer;
import net.sf.cglib.proxy.NoOp;
import net.sf.cglib.reflect.FastClass;
import net.sf.cglib.reflect.FastConstructor;
import org.aopalliance.intercept.MethodInterceptor;
import org.aopalliance.intercept.ConstructorInterceptor;
import org.aopalliance.intercept.ConstructorInvocation;

/**
 * Proxies classes applying interceptors to methods.
 *
 * @author crazybob@google.com (Bob Lee)
 */
class ProxyFactory implements ConstructionProxyFactory {

  final List<MethodAspect> methodAspects;
  final List<ConstructorAspect> constructorAspects;
  final ConstructionProxyFactory defaultFactory;

  ProxyFactory(List<MethodAspect> methodAspects, List<ConstructorAspect> constructorAspects) {
    this.methodAspects = methodAspects;
    this.constructorAspects = constructorAspects;
    defaultFactory = new DefaultConstructionProxyFactory();
  }

  @SuppressWarnings("unchecked") // the constructed T is the same as the injection point's T
  public <T> ConstructionProxy<T> get(Errors errors, InjectionPoint injectionPoint)
      throws ErrorsException {
    return (ConstructionProxy<T>) constructionProxies.get(injectionPoint, errors);
  }

  /** Cached construction proxies for each injection point */
  FailableCache<InjectionPoint, ConstructionProxy> constructionProxies
      = new FailableCache<InjectionPoint, ConstructionProxy>() {
    protected ConstructionProxy create(InjectionPoint key, Errors errors) throws ErrorsException {
      return createConstructionProxy(errors, key);
    }
  };

  <T> ConstructionProxy<T> createConstructionProxy(Errors errors, InjectionPoint injectionPoint)
      throws ErrorsException {
    @SuppressWarnings("unchecked") // the member of injectionPoint is always a Constructor<T>
    Constructor<T> constructor = (Constructor<T>) injectionPoint.getMember();
    Class<T> declaringClass = constructor.getDeclaringClass();

    // Find applicable aspects. Bow out if none are applicable to this class.
    List<MethodAspect> applicableAspects = Lists.newArrayList();
    for (MethodAspect methodAspect : methodAspects) {
      if (methodAspect.matches(declaringClass)) {
        applicableAspects.add(methodAspect);
      }
    }
    if (applicableAspects.isEmpty()) {
      return wrapConstructorProxy(defaultFactory.get(errors, injectionPoint));
    }

    // Get list of methods from cglib.
    List<Method> methods = Lists.newArrayList();
    Enhancer.getMethods(declaringClass, null, methods);
    final Map<Method, Integer> indices = Maps.newHashMap();

    // Create method/interceptor holders and record indices.
    List<MethodInterceptorsPair> methodInterceptorsPairs = Lists.newArrayList();
    for (int i = 0; i < methods.size(); i++) {
      Method method = methods.get(i);
      methodInterceptorsPairs.add(new MethodInterceptorsPair(method));
      indices.put(method, i);
    }

    // true if all the methods we're intercepting are public. This impacts which classloader we
    // should use for loading the enhanced class
    Visibility visibility = Visibility.PUBLIC;

    // Iterate over aspects and add interceptors for the methods they apply to
    boolean anyMatched = false;
    for (MethodAspect methodAspect : applicableAspects) {
      for (MethodInterceptorsPair pair : methodInterceptorsPairs) {
        if (methodAspect.matches(pair.method)) {
          visibility = visibility.and(Visibility.forMember(pair.method));
          pair.addAll(methodAspect.interceptors());
          anyMatched = true;
        }
      }
    }
    if (!anyMatched) {
      // not test-covered
      return wrapConstructorProxy(defaultFactory.get(errors, injectionPoint));
    }

    // Create callbacks.
    Callback[] callbacks = new Callback[methods.size()];

    @SuppressWarnings("unchecked") Class<? extends Callback>[] callbackTypes = new Class[methods
        .size()];
    for (int i = 0; i < methods.size(); i++) {
      MethodInterceptorsPair pair = methodInterceptorsPairs.get(i);
      if (!pair.hasInterceptors()) {
        callbacks[i] = NoOp.INSTANCE;
        callbackTypes[i] = NoOp.class;
      }
      else {
        callbacks[i] = new InterceptorStackCallback(pair.method, pair.interceptors);
        callbackTypes[i] = net.sf.cglib.proxy.MethodInterceptor.class;
      }
    }

    // Create the proxied class.
    Enhancer enhancer = newEnhancer(declaringClass, visibility);
    enhancer.setCallbackFilter(new CallbackFilter() {
      public int accept(Method method) {
        return indices.get(method);
      }
    });
    enhancer.setCallbackTypes(callbackTypes);

    Class<?> proxied = enhancer.createClass();

    // Store callbacks.
    Enhancer.registerStaticCallbacks(proxied, callbacks);

    return wrapConstructorProxy(createConstructionProxy(proxied, injectionPoint));
  }

  /**
   * Creates a construction proxy given a class and parameter types.
   */
  private <T> ConstructionProxy<T> createConstructionProxy(final Class<?> clazz,
      final InjectionPoint injectionPoint) throws ErrorsException {
    @SuppressWarnings("unchecked") // injection point's member must be a Constructor<T>
    final Constructor<T> standardConstructor = (Constructor<T>) injectionPoint.getMember();
    FastClass fastClass = newFastClass(clazz, Visibility.PUBLIC);
    final FastConstructor fastConstructor
        = fastClass.getConstructor(standardConstructor.getParameterTypes());

    return new ConstructionProxy<T>() {
      @SuppressWarnings("unchecked")
      public T newInstance(Object... arguments) throws InvocationTargetException {
        return (T) fastConstructor.newInstance(arguments);
      }

      public InjectionPoint getInjectionPoint() {
        return injectionPoint;
      }

      public Constructor<T> getConstructor() {
        return standardConstructor;
      }
    };
  }

  private <T> ConstructionProxy<T> wrapConstructorProxy(final ConstructionProxy<?> constructionProxy) {
    if (constructorAspects.isEmpty()) {
      return (ConstructionProxy<T>) constructionProxy;
    }
    else {
      // lets wrap the construction proxy to process the interceptors
      return new ConstructionProxy<T>() {
        public T newInstance(final Object... arguments) throws InvocationTargetException {
          @SuppressWarnings("unchecked")
          T answer = (T) constructionProxy.newInstance(arguments);
          for (ConstructorAspect aspect : constructorAspects) {
            List<ConstructorInterceptor> interceptors = aspect.interceptors();
            for (ConstructorInterceptor interceptor : interceptors) {
              final T currentValue = answer;
              ConstructorInvocation invocation = new ConstructorInvocation() {
                public Constructor getConstructor() {
                  return constructionProxy.getConstructor();
                }

                public Object[] getArguments() {
                  return arguments;
                }

                public Object proceed() throws Throwable {
                  return currentValue;
                }

                public Object getThis() {
                  // TODO
                  return currentValue;
                }

                public AccessibleObject getStaticPart() {
                  // TODO
                  return null;
                }
              };
              try {
                answer = (T) interceptor.construct(invocation);
              }
              catch (Throwable throwable) {
                throw new InvocationTargetException(throwable);
              }
            }
          }
          return answer;
        }

        public InjectionPoint getInjectionPoint() {
          return constructionProxy.getInjectionPoint();
        }

        public Constructor<T> getConstructor() {
          return (Constructor<T>) constructionProxy.getConstructor();
        }
      };
    }
  }

  static class MethodInterceptorsPair {

    final Method method;
    List<MethodInterceptor> interceptors;

    public MethodInterceptorsPair(Method method) {
      this.method = method;
    }

    void addAll(List<MethodInterceptor> interceptors) {
      if (this.interceptors == null) {
        this.interceptors = new ArrayList<MethodInterceptor>();
      }
      this.interceptors.addAll(interceptors);
    }

    boolean hasInterceptors() {
      return interceptors != null;
    }
  }
}
